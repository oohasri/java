package com.codingdojo.web.models;

public class Counter {

}
