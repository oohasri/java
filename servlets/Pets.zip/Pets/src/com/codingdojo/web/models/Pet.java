package com.codingdojo.web.models;

public interface Pet {
	String showAffection();
}
